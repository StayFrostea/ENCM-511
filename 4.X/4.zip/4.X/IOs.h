#ifndef IOS_AND_CLK_H
#define	IOS_AND_CLK_H

void IOinit(void);
void IOcheck(void);
void NewClk(unsigned int);

#endif	/* XC_HEADER_TEMPLATE_H */
