/*
 * File:   ChangeClk.h
 * Author: rvyas
 *
 * Created on November 19, 2016, 8:05 PM
 */

#ifndef CHANGECLK_H
#define CHANGECLK_H

void NewClk(unsigned int);

#endif /* CHANGECLK_H */
