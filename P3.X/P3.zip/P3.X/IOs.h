#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> 

#ifdef	__cplusplus

#endif /* __cplusplus */

#ifdef	__cplusplus
}
#endif /* __cplusplus */

void IOinit(void);
void IOcheck(void);
//void IOrun(void);

////Declaring global variables
//extern unsigned int GlobalVar;

#endif	/* XC_HEADER_TEMPLATE_H */