/* 
 * File:   main.c
 * Author: longt
 *
 * Created on October 20, 2020, 12:47 AM
 */
// User header files
#include "IOs.h"

void main(void) {
    IOinit();
    IOcheck(); 
}


